import React, { createContext, useState } from 'react';
import { 
  View, 
  Text, 
  Image, 
  TouchableOpacity, 
  StyleSheet, 
  ScrollView 
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// IMPORTS DAS TELAS DE CADASTRO
import CadastroAlunoScreen from './assets/telas/telaAlunos';
import CadastroProfessorScreen from './assets/telas/telaProfessores';
import CadastroTurmaScreen from './assets/telas/telaTurmas';
import CadastroCursoScreen from './assets/telas/telaCursos';
import CadastroDisciplinaScreen from './assets/telas/telaDisciplinas';
import CadastroMatriculaScreen from './assets/telas/telaMatriculas';
import CadastroResponsavelScreen from './assets/telas/telaResponsaveis';
import CadastroAvaliacaoScreen from './assets/telas/telaAvaliacoes';
import CadastroCoordenadorScreen from './assets/telas/telaCoordenadores';
import CadastroBoletimScreen from './assets/telas/telaBoletins';

// IMPORTS DAS TELAS DE CONSULTA
import ConsultaAlunosScreen from './assets/telas/consultaAluno';
import ConsultaProfessoresScreen from './assets/telas/consultaProfessor';
import ConsultaTurmasScreen from './assets/telas/consultaTurma';
import ConsultaCursosScreen from './assets/telas/consultaCurso';
import ConsultaDisciplinasScreen from './assets/telas/consultaDisciplina';
import ConsultaMatriculasScreen from './assets/telas/consultaMatricula';
import ConsultaResponsaveisScreen from './assets/telas/consultaResponsavel';
import ConsultaAvaliacoesScreen from './assets/telas/consultaAvaliacao';
import ConsultaCoordenadoresScreen from './assets/telas/consultaCoordenador';
import ConsultaBoletinsScreen from './assets/telas/consultaBoletim';

// Criação do Contexto Global para armazenar e excluir dados de verdade
export const AppContext = createContext();

const Stack = createNativeStackNavigator();

function HomeScreen({ navigation }) {
  const modulos = [
    { nome: 'Alunos', cadastro: 'CadastroAluno', consulta: 'ConsultaAlunos' },
    { nome: 'Professores', cadastro: 'CadastroProfessor', consulta: 'ConsultaProfessores' },
    { nome: 'Turmas', cadastro: 'CadastroTurma', consulta: 'ConsultaTurmas' },
    { nome: 'Cursos', cadastro: 'CadastroCurso', consulta: 'ConsultaCursos' },
    { nome: 'Disciplinas', cadastro: 'CadastroDisciplina', consulta: 'ConsultaDisciplinas' },
    { nome: 'Matrículas', cadastro: 'CadastroMatricula', consulta: 'ConsultaMatriculas' },
    { nome: 'Responsáveis', cadastro: 'CadastroResponsavel', consulta: 'ConsultaResponsaveis' },
    { nome: 'Avaliações', cadastro: 'CadastroAvaliacao', consulta: 'ConsultaAvaliacoes' },
    { nome: 'Coordenadores', cadastro: 'CadastroCoordenador', consulta: 'ConsultaCoordenadores' },
    { nome: 'Boletins', cadastro: 'CadastroBoletim', consulta: 'ConsultaBoletins' },
  ];

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Image source={require('./components/images.jpg')} style={styles.logo} />
      <Text style={styles.titulo}>APP Scholar</Text>
      <Text style={styles.subtitulo}>Sistema Acadêmico Mobile</Text>
      
      {modulos.map((item, index) => (
        <View key={index} style={styles.cardModulo}>
          <Text style={styles.tituloModulo}>{item.nome}</Text>
          <View style={styles.boxBotoes}>
            <TouchableOpacity 
              style={[styles.botao, styles.btnCadastro]} 
              onPress={() => navigation.navigate(item.cadastro)}
            >
              <Text style={styles.textoBotao}>Cadastrar</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[styles.botao, styles.btnConsulta]} 
              onPress={() => navigation.navigate(item.consulta)}
            >
              <Text style={styles.textoBotao}>Consultar</Text>
            </TouchableOpacity>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

export default function App() {
  // Estados para salvar as listas de registros globalmente
  const [alunos, setAlunos] = useState([]);
  const [professores, setProfessores] = useState([]);
  const [turmas, setTurmas] = useState([]);
  const [cursos, setCursos] = useState([]);
  const [disciplinas, setDisciplinas] = useState([]);
  const [matriculas, setMatriculas] = useState([]);
  const [responsaveis, setResponsaveis] = useState([]);
  const [avaliacoes, setAvaliacoes] = useState([]);
  const [coordenadores, setCoordenadores] = useState([]);
  const [boletins, setBoletins] = useState([]);

  // Função genérica para deletar um item de qualquer lista usando ID/Index
  const excluirItem = (entidade, id) => {
    if (entidade === 'alunos') setAlunos(alunos.filter(item => item.id !== id));
    if (entidade === 'professores') setProfessores(professores.filter(item => item.id !== id));
    if (entidade === 'turmas') setTurmas(turmas.filter(item => item.id !== id));
    if (entidade === 'cursos') setCursos(cursos.filter(item => item.id !== id));
    if (entidade === 'disciplinas') setDisciplinas(disciplinas.filter(item => item.id !== id));
    if (entidade === 'matriculas') setMatriculas(matriculas.filter(item => item.id !== id));
    if (entidade === 'responsaveis') setResponsaveis(responsaveis.filter(item => item.id !== id));
    if (entidade === 'avaliacoes') setAvaliacoes(avaliacoes.filter(item => item.id !== id));
    if (entidade === 'coordenadores') setCoordenadores(coordenadores.filter(item => item.id !== id));
    if (entidade === 'boletins') setBoletins(boletins.filter(item => item.id !== id));
  };

  return (
    <AppContext.Provider value={{
      alunos, setAlunos,
      professores, setProfessores,
      turmas, setTurmas,
      cursos, setCursos,
      disciplinas, setDisciplinas,
      matriculas, setMatriculas,
      responsaveis, setResponsaveis,
      avaliacoes, setAvaliacoes,
      coordenadores, setCoordenadores,
      boletins, setBoletins,
      excluirItem
    }}>
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: '#1565C0' }, headerTintColor: '#fff' }}>
          <Stack.Screen name="Inicio" component={HomeScreen} options={{ title: 'Menu App Scholar' }} />
          
          {/* ROTAS DE CADASTRO */}
          <Stack.Screen name="CadastroAluno" component={CadastroAlunoScreen} options={{ title: 'Cadastrar Aluno' }} />
          <Stack.Screen name="CadastroProfessor" component={CadastroProfessorScreen} options={{ title: 'Cadastrar Professor' }} />
          <Stack.Screen name="CadastroTurma" component={CadastroTurmaScreen} options={{ title: 'Cadastrar Turma' }} />
          <Stack.Screen name="CadastroCurso" component={CadastroCursoScreen} options={{ title: 'Cadastrar Curso' }} />
          <Stack.Screen name="CadastroDisciplina" component={CadastroDisciplinaScreen} options={{ title: 'Cadastrar Disciplina' }} />
          <Stack.Screen name="CadastroMatricula" component={CadastroMatriculaScreen} options={{ title: 'Cadastrar Matrícula' }} />
          <Stack.Screen name="CadastroResponsavel" component={CadastroResponsavelScreen} options={{ title: 'Cadastrar Responsável' }} />
          <Stack.Screen name="CadastroAvaliacao" component={CadastroAvaliacaoScreen} options={{ title: 'Cadastrar Avaliação' }} />
          <Stack.Screen name="CadastroCoordenador" component={CadastroCoordenadorScreen} options={{ title: 'Cadastrar Coordenador' }} />
          <Stack.Screen name="CadastroBoletim" component={CadastroBoletimScreen} options={{ title: 'Cadastrar Boletim' }} />

          {/* ROTAS DE CONSULTA */}
          <Stack.Screen name="ConsultaAlunos" component={ConsultaAlunosScreen} options={{ title: 'Consultar Alunos' }} />
          <Stack.Screen name="ConsultaProfessores" component={ConsultaProfessoresScreen} options={{ title: 'Consultar Professores' }} />
          <Stack.Screen name="ConsultaTurmas" component={ConsultaTurmasScreen} options={{ title: 'Consultar Turmas' }} />
          <Stack.Screen name="ConsultaCursos" component={ConsultaCursosScreen} options={{ title: 'Consultar Cursos' }} />
          <Stack.Screen name="ConsultaDisciplinas" component={ConsultaDisciplinasScreen} options={{ title: 'Consultar Disciplinas' }} />
          <Stack.Screen name="ConsultaMatriculas" component={ConsultaMatriculasScreen} options={{ title: 'Consultar Matrículas' }} />
          <Stack.Screen name="ConsultaResponsaveis" component={ConsultaResponsaveisScreen} options={{ title: 'Consultar Responsáveis' }} />
          <Stack.Screen name="ConsultaAvaliacoes" component={ConsultaAvaliacoesScreen} options={{ title: 'Consultar Avaliações' }} />
          <Stack.Screen name="ConsultaCoordenadores" component={ConsultaCoordenadoresScreen} options={{ title: 'Consultar Coordenadores' }} />
          <Stack.Screen name="ConsultaBoletins" component={ConsultaBoletinsScreen} options={{ title: 'Consultar Boletins' }} />
        </Stack.Navigator>
      </NavigationContainer>
    </AppContext.Provider>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, padding: 20, backgroundColor: '#F5F5F5', alignItems: 'center' },
  logo: { width: 100, height: 100, marginBottom: 10, borderRadius: 50 },
  titulo: { fontSize: 28, fontWeight: 'bold', color: '#1565C0' },
  subtitulo: { fontSize: 16, marginBottom: 25, color: '#666' },
  cardModulo: { width: '100%', backgroundColor: '#FFF', padding: 15, borderRadius: 8, marginBottom: 15, elevation: 2 },
  tituloModulo: { fontSize: 18, fontWeight: 'bold', color: '#333', marginBottom: 10 },
  boxBotoes: { flexDirection: 'row', justifyContent: 'space-between' },
  botao: { width: '48%', padding: 12, borderRadius: 6, alignItems: 'center' },
  btnCadastro: { backgroundColor: '#1976D2' },
  btnConsulta: { backgroundColor: '#388E3C' },
  textoBotao: { color: '#FFF', fontSize: 15, fontWeight: 'bold' }
});
