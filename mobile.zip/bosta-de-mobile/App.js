import React from 'react';

import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  ScrollView
} from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import TelaAlunos from './assets/telas/telaAlunos';
import TelaProfessores from './assets/telas/telaProfessores';
import TelaCursos from './assets/telas/telaCursos';
import TelaResponsaveis from './assets/telas/telaResponsaveis';
import TelaMatriculas from './assets/telas/telaMatriculas';
import TelaTurmas from './assets/telas/telaTurmas';
import TelaAvaliacoes from './assets/telas/telaAvaliacoes';
import TelaCoordenadores from './assets/telas/telaCoordenadores';
import TelaBoletins from './assets/telas/telaBoletins';
import TelaDisciplinas from './assets/telas/telaDisciplinas';

const Stack = createNativeStackNavigator();


function TelaInicial({ navigation }) {

  return (
    <ScrollView contentContainerStyle={styles.container}>

      <Image
        source={require('./components/images.jpg')}
        style={styles.logo}
      />

      <Text style={styles.titulo}>
        APP Scholar
      </Text>

      <Text style={styles.subtitulo}>
        Sistema Academico Mobile
      </Text>


      <TouchableOpacity
        style={styles.botao}
        onPress={() => navigation.navigate('Alunos')}
      >
        <Text style={styles.textoBotao}>
          Alunos
        </Text>
      </TouchableOpacity>


      <TouchableOpacity
        style={styles.botao}
        onPress={() => navigation.navigate('Professores')}
      >
        <Text style={styles.textoBotao}>
          Professores
        </Text>
      </TouchableOpacity>


      <TouchableOpacity
        style={styles.botao}
        onPress={() => navigation.navigate('Cursos')}
      >
        <Text style={styles.textoBotao}>
          Cursos
        </Text>
      </TouchableOpacity>


      <TouchableOpacity
        style={styles.botao}
        onPress={() => navigation.navigate('Responsaveis')}
      >
        <Text style={styles.textoBotao}>
          Responsáveis
        </Text>
      </TouchableOpacity>


      <TouchableOpacity
        style={styles.botao}
        onPress={() => navigation.navigate('Matriculas')}
      >
        <Text style={styles.textoBotao}>
          Matrículas
        </Text>
      </TouchableOpacity>


      <TouchableOpacity
        style={styles.botao}
        onPress={() => navigation.navigate('Turmas')}
      >
        <Text style={styles.textoBotao}>
          Turmas
        </Text>
      </TouchableOpacity>


      <TouchableOpacity
        style={styles.botao}
        onPress={() => navigation.navigate('Avaliacoes')}
      >
        <Text style={styles.textoBotao}>
          Avaliações
        </Text>
      </TouchableOpacity>


      <TouchableOpacity
        style={styles.botao}
        onPress={() => navigation.navigate('Coordenadores')}
      >
        <Text style={styles.textoBotao}>
          Coordenadores
        </Text>
      </TouchableOpacity>


      <TouchableOpacity
        style={styles.botao}
        onPress={() => navigation.navigate('Boletins')}
      >
        <Text style={styles.textoBotao}>
          Boletins
        </Text>
      </TouchableOpacity>


      <TouchableOpacity
        style={styles.botao}
        onPress={() => navigation.navigate('Disciplinas')}
      >
        <Text style={styles.textoBotao}>
          Disciplinas
        </Text>
      </TouchableOpacity>

    </ScrollView>
  );
}


export default function App() {

  return (
    <NavigationContainer>

      <Stack.Navigator>

        <Stack.Screen
          name="Inicio"
          component={TelaInicial}
          options={{
            title: 'APP Scholar'
          }}
        />

        <Stack.Screen
          name="Alunos"
          component={TelaAlunos}
          options={{
            title: 'Alunos'
          }}
        />

        <Stack.Screen
          name="Professores"
          component={TelaProfessores}
          options={{
            title: 'Professores'
          }}
        />

        <Stack.Screen
          name="Cursos"
          component={TelaCursos}
          options={{
            title: 'Cursos'
          }}
        />

        <Stack.Screen
          name="Responsaveis"
          component={TelaResponsaveis}
          options={{
            title: 'Responsáveis'
          }}
        />

        <Stack.Screen
          name="Matriculas"
          component={TelaMatriculas}
          options={{
            title: 'Matrículas'
          }}
        />

        <Stack.Screen
          name="Turmas"
          component={TelaTurmas}
          options={{
            title: 'Turmas'
          }}
        />

        <Stack.Screen
          name="Avaliacoes"
          component={TelaAvaliacoes}
          options={{
            title: 'Avaliações'
          }}
        />

        <Stack.Screen
          name="Coordenadores"
          component={TelaCoordenadores}
          options={{
            title: 'Coordenadores'
          }}
        />

        <Stack.Screen
          name="Boletins"
          component={TelaBoletins}
          options={{
            title: 'Boletins'
          }}
        />

        <Stack.Screen
          name="Disciplinas"
          component={TelaDisciplinas}
          options={{
            title: 'Disciplinas'
          }}
        />

      </Stack.Navigator>

    </NavigationContainer>
  );
}


const styles = StyleSheet.create({

  container: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20
  },

  logo: {
    width: 150,
    height: 150,
    marginBottom: 20
  },

  titulo: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#1565C0'
  },

  subtitulo: {
    fontSize: 18,
    marginBottom: 40,
    color: '#666'
  },

  botao: {
    width: '80%',
    backgroundColor: '#1976D2',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    alignItems: 'center'
  },

  textoBotao: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF'
  }

});