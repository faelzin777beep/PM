import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView
} from 'react-native';

export default function TelaCursos({ navigation }) {

  const [nome, setNome] = useState('');
  const [duracao, setDuracao] = useState('');
  const [descricao, setDescricao] = useState('');

  const cadastrarCurso = () => {

    if (
      nome === '' ||
      duracao === '' ||
      descricao === ''
    ) {
      Alert.alert(
        'Atenção',
        'Preencha todos os campos.'
      );

      return;
    }

    Alert.alert(
      'Cadastro realizado',
      `Curso ${nome} cadastrado com sucesso!`
    );

    setNome('');
    setDuracao('');
    setDescricao('');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>

      <Text style={styles.titulo}>
        Cadastro de Curso
      </Text>

      <Text style={styles.label}>
        Nome do curso
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Digite o nome do curso"
        value={nome}
        onChangeText={setNome}
      />

      <Text style={styles.label}>
        Duração
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Ex: 3 anos"
        value={duracao}
        onChangeText={setDuracao}
      />

      <Text style={styles.label}>
        Descrição
      </Text>

      <TextInput
        style={[styles.input, styles.inputGrande]}
        placeholder="Digite a descrição do curso"
        value={descricao}
        onChangeText={setDescricao}
        multiline
      />

      <TouchableOpacity
        style={styles.botao}
        onPress={cadastrarCurso}
      >
        <Text style={styles.textoBotao}>
          Cadastrar Curso
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.botaoVoltar}
        onPress={() => navigation.navigate('Inicio')}
      >
        <Text style={styles.textoBotao}>
          Voltar para o início
        </Text>
      </TouchableOpacity>

    </ScrollView>
  );
}

const styles = StyleSheet.create({

  container: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: '#FFFFFF'
  },

  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1565C0',
    textAlign: 'center',
    marginBottom: 30
  },

  label: {
    fontSize: 17,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#333333'
  },

  input: {
    width: '100%',
    height: 50,
    borderWidth: 1,
    borderColor: '#BBBBBB',
    borderRadius: 8,
    paddingHorizontal: 15,
    marginBottom: 20,
    fontSize: 16,
    backgroundColor: '#F9F9F9'
  },

  inputGrande: {
    height: 100,
    textAlignVertical: 'top',
    paddingTop: 12
  },

  botao: {
    width: '100%',
    backgroundColor: '#1976D2',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10
  },

  botaoVoltar: {
    width: '100%',
    backgroundColor: '#666666',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 15
  },

  textoBotao: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold'
  }

});