import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView
} from 'react-native';

export default function TelaAvaliacoes({ navigation }) {

  const [aluno, setAluno] = useState('');
  const [disciplina, setDisciplina] = useState('');
  const [nota, setNota] = useState('');
  const [data, setData] = useState('');

  const cadastrarAvaliacao = () => {

    if (
      aluno === '' ||
      disciplina === '' ||
      nota === '' ||
      data === ''
    ) {
      Alert.alert(
        'Atenção',
        'Preencha todos os campos.'
      );

      return;
    }

    Alert.alert(
      'Cadastro realizado',
      `Avaliação do aluno ${aluno} cadastrada com sucesso!`
    );

    setAluno('');
    setDisciplina('');
    setNota('');
    setData('');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>

      <Text style={styles.titulo}>
        Cadastro de Avaliação
      </Text>

      <Text style={styles.label}>
        Aluno
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Digite o nome do aluno"
        value={aluno}
        onChangeText={setAluno}
      />

      <Text style={styles.label}>
        Disciplina
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Digite a disciplina"
        value={disciplina}
        onChangeText={setDisciplina}
      />

      <Text style={styles.label}>
        Nota
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Digite a nota"
        value={nota}
        onChangeText={setNota}
        keyboardType="decimal-pad"
      />

      <Text style={styles.label}>
        Data da avaliação
      </Text>

      <TextInput
        style={styles.input}
        placeholder="DD/MM/AAAA"
        value={data}
        onChangeText={setData}
      />

      <TouchableOpacity
        style={styles.botao}
        onPress={cadastrarAvaliacao}
      >
        <Text style={styles.textoBotao}>
          Cadastrar Avaliação
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.botaoVoltar}
        onPress={() => navigation.navigate('Inicio')}
      >
        <Text style={styles.textoBotao}>
          Voltar para o início
        </Text>
      </TouchableOpacity>

    </ScrollView>
  );
}

const styles = StyleSheet.create({

  container: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: '#FFFFFF'
  },

  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1565C0',
    textAlign: 'center',
    marginBottom: 30
  },

  label: {
    fontSize: 17,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#333333'
  },

  input: {
    width: '100%',
    height: 50,
    borderWidth: 1,
    borderColor: '#BBBBBB',
    borderRadius: 8,
    paddingHorizontal: 15,
    marginBottom: 20,
    fontSize: 16,
    backgroundColor: '#F9F9F9'
  },

  botao: {
    width: '100%',
    backgroundColor: '#1976D2',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10
  },

  botaoVoltar: {
    width: '100%',
    backgroundColor: '#666666',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 15
  },

  textoBotao: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold'
  }

});