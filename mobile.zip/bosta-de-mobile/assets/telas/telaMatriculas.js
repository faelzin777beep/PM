import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView
} from 'react-native';

export default function TelaMatriculas({ navigation }) {

  const [aluno, setAluno] = useState('');
  const [curso, setCurso] = useState('');
  const [data, setData] = useState('');
  const [status, setStatus] = useState('');

  const cadastrarMatricula = () => {

    if (
      aluno === '' ||
      curso === '' ||
      data === '' ||
      status === ''
    ) {
      Alert.alert(
        'Atenção',
        'Preencha todos os campos.'
      );

      return;
    }

    Alert.alert(
      'Cadastro realizado',
      `Matrícula do aluno ${aluno} cadastrada com sucesso!`
    );

    setAluno('');
    setCurso('');
    setData('');
    setStatus('');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>

      <Text style={styles.titulo}>
        Cadastro de Matrícula
      </Text>

      <Text style={styles.label}>
        Aluno
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Digite o nome do aluno"
        value={aluno}
        onChangeText={setAluno}
      />

      <Text style={styles.label}>
        Curso
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Digite o curso"
        value={curso}
        onChangeText={setCurso}
      />

      <Text style={styles.label}>
        Data da matrícula
      </Text>

      <TextInput
        style={styles.input}
        placeholder="DD/MM/AAAA"
        value={data}
        onChangeText={setData}
      />

      <Text style={styles.label}>
        Status
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Ex: Ativa"
        value={status}
        onChangeText={setStatus}
      />

      <TouchableOpacity
        style={styles.botao}
        onPress={cadastrarMatricula}
      >
        <Text style={styles.textoBotao}>
          Cadastrar Matrícula
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.botaoVoltar}
        onPress={() => navigation.navigate('Inicio')}
      >
        <Text style={styles.textoBotao}>
          Voltar para o início
        </Text>
      </TouchableOpacity>

    </ScrollView>
  );
}

const styles = StyleSheet.create({

  container: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: '#FFFFFF'
  },

  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1565C0',
    textAlign: 'center',
    marginBottom: 30
  },

  label: {
    fontSize: 17,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#333333'
  },

  input: {
    width: '100%',
    height: 50,
    borderWidth: 1,
    borderColor: '#BBBBBB',
    borderRadius: 8,
    paddingHorizontal: 15,
    marginBottom: 20,
    fontSize: 16,
    backgroundColor: '#F9F9F9'
  },

  botao: {
    width: '100%',
    backgroundColor: '#1976D2',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10
  },

  botaoVoltar: {
    width: '100%',
    backgroundColor: '#666666',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 15
  },

  textoBotao: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold'
  }

});